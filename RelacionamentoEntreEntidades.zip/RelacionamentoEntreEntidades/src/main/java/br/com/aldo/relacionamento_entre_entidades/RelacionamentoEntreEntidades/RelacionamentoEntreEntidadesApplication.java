package br.com.aldo.relacionamento_entre_entidades.RelacionamentoEntreEntidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelacionamentoEntreEntidadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelacionamentoEntreEntidadesApplication.class, args);
	}

}
