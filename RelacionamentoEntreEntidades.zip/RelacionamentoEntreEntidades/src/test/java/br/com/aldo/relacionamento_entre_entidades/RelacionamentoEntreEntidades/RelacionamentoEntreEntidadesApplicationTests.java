package br.com.aldo.relacionamento_entre_entidades.RelacionamentoEntreEntidades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelacionamentoEntreEntidadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
